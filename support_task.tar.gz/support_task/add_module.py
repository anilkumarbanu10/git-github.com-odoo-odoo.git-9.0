# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-2010 Tiny SPRL (<http://tiny.be>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
#
from openerp.osv import osv,fields
from openerp import models, fields, api,_
from openerp.tools.translate import _
import time
from datetime import datetime
import sys, os, urllib2, urlparse
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
from email.MIMEMultipart import MIMEMultipart
import email, re
from datetime import datetime
from datetime import date, timedelta
import cgi
import lxml.html
import lxml.html.clean as clean
from lxml import etree
import cgi
import logging
import openerp.pooler as pooler
import random
import re
import socket
import threading

_logger = logging.getLogger(__name__)


class add_module(models.Model):
    _name="add.module"
    
    project_name=fields.Many2one('manage.project','Project Name', required=True)
    name= fields.Char('Module Name',size=50 ,required=True)
    code= fields.Char('Module Code',size=50)
       
             
    _sql_constraints = [
        ('name_uniq', 'unique (name)', 'Module Name Should be Unique!'),
        ('code_uniq', 'unique (code)', 'Module Code Should Be Unique!')
    ]  
add_module()


#class support_count(osv.osv):
   # _name = 'support.count'
 #   _description = "support count details"

#    _columns = {
#        'from_date':fields.datetime('From Date'),
#	'to_date':fields.datetime('To Date'),
#        'Customer':fields.selection([('customer','customer'),('customer','customer')],'Customer'),
        
 #              }
#support_count()
#class support_det(osv.osv):
#    _name = 'support.det'
 #   _description = "support details"

 #   _columns = {
#       'Status':fields.selection([('Select Status','Select Status'),('all','All'),('clerification','Clerification'),
#('created','Created'),('Assigned to developer','Assigned to developer'),('Assigned to Support','Assigned to Support'),('verify and closed','Verify and closed'),('deployed and closed','Deployed and closed'),('cancelled','Cancelled')],'Status')
#        }
#support_det()




