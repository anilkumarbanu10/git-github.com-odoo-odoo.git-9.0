
#
from openerp.osv import osv,fields
from openerp import models, fields, api,_
from openerp.tools.translate import _
import time
from datetime import datetime
import sys, os, urllib2, urlparse
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
from email.MIMEMultipart import MIMEMultipart
import email, re
from datetime import datetime
from datetime import date, timedelta
import cgi
import lxml.html
import lxml.html.clean as clean
from lxml import etree
import cgi
import logging
import openerp.pooler as pooler
import random
import re
import socket
import threading

_logger = logging.getLogger(__name__)

class add_supp_det(models.Model):
   _name ='add.supp.det'
   _description = "Addsupport details"
   _order="id desc"
   
   @api.one
   @api.multi
   def _get_auto(self):
        x = {}
        month_value=0
        year_value=0
        next_year=0
        dispay_year=''
        display_present_year=''
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        print '-------------------------------------1-------------------------------------'
        for temp in self:
            cr.execute('''select cast(extract (month from rec_date) as integer) as month ,cast(extract (year from rec_date) as integer) as year ,id from add_supp_det where id=%s''',((temp.id),))
            print '--------------------------------2------------------------------------------'
            for item in cr.dictfetchall():
                month_value=int(item['month'])
                year_value=int(item['year'])
                if month_value<=3:
                    year_value=year_value-1
                else:
                    year_value=year_value
                    next_year=year_value+1
                    dispay_year=str(next_year)[-2:]
                    display_present_year=str(year_value)[-2:]
                        
                    cr.execute('''select autogenerate_add_supp_det(%s)''', ((temp.id),)  ) 
                    result = cr.dictfetchall()
                    parent_invoice_id = 0
                    print '---------------------------------3-----------------------------------------'
                for value in result: parent_invoice_id = value['autogenerate_add_supp_det'];
                auto_gen = int(parent_invoice_id)
                if len(str(auto_gen)) < 2:
                    auto_gen = '000'+ str(auto_gen)
                elif len(str(auto_gen)) < 3:
                    auto_gen = '00' + str(auto_gen)
                elif len(str(auto_gen)) == 3:
                    auto_gen = '0'+str(auto_gen)
                else:
                    auto_gen = str(auto_gen)
                for record in self :
                    print '--------------------------------4------------------------------------------'
                    x[record.id] = 'PR-'+'MISC-'+str(auto_gen) +'/'+str(display_present_year)+'-'+str(dispay_year)
                    
                cr.execute('''update add_supp_det set req_name =%s where id=%s ''', ((x[record.id]),(temp.id),)  )
            return x
   
    
   
   
   support_type= fields.Selection([('Ph', 'Phone'), ('Ema', 'Email')], 'Support Type')
   req_name= fields.Char(string='Request Name')
   rec_date= fields.Date('Received Date',default=fields.Date.today)
   received_by=fields.Many2one('res.users','Received By', required=True)
   customer= fields.Many2one('manage.customer','Customer', required=True)
   code=fields.Char('Customer Code')
   project_name=fields.Many2one('manage.project','Project Name', required=True)
   module=fields.Many2one('add.module', 'Reported Module', required=True)
   called_by= fields.Char('Called By')
   summary= fields.Text('Summary')
   description= fields.Text('Description')
   type= fields.Selection([('Clarification', 'Clarification'), ('FollowUp', 'FollowUp')], 'Type')
   comments= fields.Text('Comments')
   
   indent_disable_id = fields.Integer('Indent Disable')
   indent_increment_id = fields.Integer('Ident increment No')
   
   request_name = fields.Char('Store Request Number', compute='_get_auto')
   auto_no = fields.Integer('Auto')
   req_no_control_id1 = fields.Integer('Auto Generating id',default= 0)
   
   
   @api.model
   def _default_company(self):
       return self.env['res.users']._users_default_get('res.partner')
   _defaults = {
       'support_type' : lambda *a : 'Ph',
       'type':lambda*a:'Clarification',
       'name': lambda x, y, z, c: x.pool.get('ir.sequence').get(y, z, 'add.supp.det'),
       'indent_disable_id':1,
       }

        
      
   def onchange_cust_name_id(self, cr, uid, ids, name, context=None):
        
        try:
            cust_name = self.pool.get('manage.customer').browse(cr, uid, name, context=context)
        
            result = {
                'code': cust_name.code
                }
            return {'value': result}
        except:
            a = 1
      



