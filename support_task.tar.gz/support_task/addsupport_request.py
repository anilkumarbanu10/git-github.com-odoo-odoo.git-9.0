    # -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-2010 Tiny SPRL (<http://tiny.be>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
#

from openerp.osv import osv,fields
from openerp import models, fields, api,_
from openerp.tools.translate import _
import time
from datetime import datetime
import sys, os, urllib2, urlparse
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
from email.MIMEMultipart import MIMEMultipart
import email, re
from datetime import datetime
from datetime import date, timedelta
import cgi
import lxml.html
import lxml.html.clean as clean
from lxml import etree
import cgi
import openerp.pooler as pooler
import random
import re
import socket
import threading

import logging

_logger = logging.getLogger(__name__)


class addsupport_request(models.Model):
    _name="addsupport.request"
    _rec_name = 'rai_name'
    _order="id desc"
    

    
    
    #@api.one
    #@api.multi
    #def _get_auto(self):
         #x = {}
         #month_value=0
         #year_value=0
         #next_year=0
         #dispay_year=''
         #display_present_year=''
         #cr = self.env.cr
         #uid = self.env.uid
         #ids = self.ids
         #print '-------------------------------------1-------------------------------------'
         #for temp in self:
             #cr.execute('''select cast(extract (month from rec_date) as integer) as month ,cast(extract (year from rec_date) as integer) as year ,id from addsupport_request where id=%s''',((temp.id),))
             #print '--------------------------------2------------------------------------------'
             #for item in cr.dictfetchall():
                 #month_value=int(item['month'])
                 #year_value=int(item['year'])
                 #if month_value<=3:
                     #year_value=year_value-1
                 #else:
                     #year_value=year_value
                     #next_year=year_value+1
                     #dispay_year=str(next_year)[-2:]
                     #display_present_year=str(year_value)[-2:]
                        
                     #cr.execute('''select autogenerate_addsupport_request(%s)''', ((temp.id),)  ) 
                     #result = cr.dictfetchall()
                     #parent_invoice_id = 0
                     #print '---------------------------------3-----------------------------------------'
                     #for value in result: parent_invoice_id = value['autogenerate_addsupport_request'];
                     #auto_gen = int(parent_invoice_id)
                     #if len(str(auto_gen)) < 2:
                         #auto_gen = '000'+ str(auto_gen)
                     #elif len(str(auto_gen)) < 3:
                         #auto_gen = '00' + str(auto_gen)
                     #elif len(str(auto_gen)) == 3:
                         #auto_gen = '0'+str(auto_gen)
                     #else:
                         #auto_gen = str(auto_gen)
                     #for record in self :
                         #print '--------------------------------4------------------------------------------'
                         #x[record.id] = 'PR-'+'MISC-'+str(auto_gen) +'/'+str(display_present_year)+'-'+str(dispay_year)
                     #cr.execute('''update addsupport_request set rai_name =%s where id=%s ''', ((x[record.id]),(temp.id),)  )
         #return x
    
    
    
    
    
  
        
    @api.depends('dev','test','bug')
    def _get_total(self):
        x={}
        for record in self:
            total_cal = record.dev + record.test + record.bug
            record.update({
                'total': total_cal
                })
    

    @api.depends('total','grid_id.actual_hours')
    def _get_remaining_hours(self):
        x={}
        for record in self:
            total_hrs = total= actual_hours= 0.0
            for line in record.grid_id:
                actual_hours += line.actual_hours
                total  = record.total
                total_hrs  = total - actual_hours
                record.update({
                    'remaining_hours': total_hrs
                    })



    rai_name= fields.Text('Ticket#')
    rec_date= fields.Date('Received Date', required=True)
    received_by= fields.Many2one('res.users','Received By', required=True)
    customer= fields.Many2one('manage.customer','Customer', required=True)
    project_name= fields.Many2one('manage.project','Project Name', required=True)
    module= fields.Many2one('add.module','Reported Module', required=True)
    reported_by= fields.Char('Reported By', required=True)
    summary= fields.Text('Summary', required=True)
    description= fields.Text('Description')
    reproduce= fields.Text('Steps to reproduce')
    priority= fields.Many2one('priority.name',string='priority', required=True)
    stat_name=fields.Many2one('status.name',string='Status', required=True)
    estimate_date=fields.Date('Estimate Date')
    actual_date= fields.Date('Actual Date')
    
    screen_created= fields.Selection([('yes','Yes'),('no','No')],'Screen created', required=True)
    dev= fields.Float('Development')
    test= fields.Float('Testing')
    bug=fields.Float('Bug Fixing')
    total= fields.Float(string='Total',compute= '_get_total',store=True)
    grid_id = fields.One2many('actual.hours', 'main_id',string='Grid')
    actual_hours=fields.Float('Actual Hours', help='Estimated time to do the task, usually set by the project manager when the task is in draft state.')
    estimated_hours=fields.Float('Estimated Hours')
    remaining_hours=fields.Float(string='Remaining Hours',compute= '_get_remaining_hours',store=True)
    a=fields.Char('A')
    b= fields.Char('B')
    
    
    indent_disable_id = fields.Integer('Indent Disable')
    indent_increment_id = fields.Integer('Ident increment No')
    
    
    #raised_name = fields.Text('Ticket Number', compute='_get_auto')
    #auto_no = fields.Integer('Auto')
    #req_no_control_id1 = fields.Integer('Auto Generating id',default= 0)
    

    
    @api.model
    def _default_company(self):
        return self.env['res.users']._users_default_get('res.partner')
    _defaults = {
        'name': lambda x, y, z, c: x.pool.get('ir.sequence').get(y, z, 'addsupport.request'),
        'a': 'No',
        'b': 'No',
        'indent_increment_id':1,
        }
    def onchange_status_id(self, cr, uid, ids, name, context=None):
        status_s=0
        if name == False:
            name=0
        cr.execute('''select id AS status_s from status_name where id = %s''', ((name),))
        for status_s in cr.dictfetchall():
            status_s = status_s['status_s']
        status = self.pool.get('status.name').browse( cr, uid, name, context=context)
        if status_s == 5:
            a = 'Yes'
        elif status_s == 9:
            a = 'Yes'
        else:
            a = 'No'
            
        if status_s == 9:                        
            b = 'Yes'
        else:
            b = 'No'
        result = {
            'a': a,
            'b': b
            }
        return {'value': result}


    
    def onchange_total_id(self, cr, uid, ids, bug,test,dev, context=None):

        total=bug+test+dev
        return {'value' :{'total': total}}
 
    
    class ActualHours(models.Model):
        _name="actual.hours"
        
        date=fields.Date('Date',default=fields.Date.today)
        assigned_to=fields.Many2one('assign.name','assign',required=True)
        actual_hours=fields.Float('Actual Hours')
        main_id = fields.Many2one('addsupport.request',string="Main class ID")
    

class assign_name(models.Model):
    _name="assign.name"
    
    name= fields.Char('Assigned To')
        

class status_name(models.Model):
    _name="status.name"
    
    name= fields.Char('Status')


class priority_name(models.Model):
    _name="priority.name"
    
    name= fields.Char('priority')
    



