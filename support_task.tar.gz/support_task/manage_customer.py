# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-2010 Tiny SPRL (<http://tiny.be>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
#
from openerp.osv import osv,fields
from openerp import models, fields, api,_
from openerp.tools.translate import _
import time
from datetime import datetime
import sys, os, urllib2, urlparse
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
from email.MIMEMultipart import MIMEMultipart
import email, re
from datetime import datetime
#from datetime import date, timedelta
import cgi
import lxml.html
import lxml.html.clean as clean
from lxml import etree
import cgi
import logging
import openerp.pooler as pooler
import random
import re
import socket
import threading

_logger = logging.getLogger(__name__)


class manage_customer(models.Model):
    _name="manage.customer"
    
    
    name= fields.Char('Name', required=True)
    code= fields.Char('Code', required=True)
    addr1= fields.Char('Address 1')
    addr2= fields.Char('Address 2')
    country= fields.Many2one('address.country','Country')
    city= fields.Many2one('address.city','City')
    state= fields.Many2one('address.state','State')
    pin= fields.Char('Pin Code')
    phone= fields.Char('Work Phone')
    fax= fields.Char('Work fax')
    site= fields.Char('Web Site')
    pan= fields.Char('PAN')
    tin= fields.Char('TIN')
    #  'project_name':fields.one2many('manage.projectname','new_id_name',string='Project Name'),
    contact= fields.One2many('contact.det','new_id', string="Add contact")
    currency= fields.Selection([('inr', 'INR'),('usd','USD')],'Currency')
    type= fields.Selection([('product', 'Product'),('openerp servicing','OPENERP servicing'),('other servicing','Other servicing')],'Type')
    sign= fields.Date('Sign off Date')
    model= fields.Selection([('saas','SAAS'),('customer server','Customer Server')],'Model')
    no_of_trucks= fields.Integer('No.of.Trucks')
    one_time= fields.Integer('One Time fee')
    custom_fee= fields.Integer('Customization fee')
    billing= fields.Selection([('truck wise','Truck wise'),('monthly fixed','Monthly Fixed')],'Billing Type')
    monthly_fee= fields.Integer('Monthly fee')
    amount= fields.Integer('AMC Amount')
        
        

    _sql_constraints=[
        ('unique_name','unique(name)', 'customer Name must be unique'),
        ('unique_code','unique(code)', 'customer Code must be unique')
	]
manage_customer()
    

class contact_det(models.Model):
    _name="contact.det"
    
    contact_name= fields.Char('Contact Name')
    position= fields.Char('Position')
    contact_no= fields.Char('Contact Number')
    email= fields.Char('Email ID')
    location= fields.Char('Location')
    new_id= fields.Many2one('manage.customer','Delete',ondelete='cascade', select=True, readonly=True)
        

    
contact_det()


##class manage_projectname(osv.osv):
##    _name="manage.projectname"
##
##    
##    _columns={
##
##        'name': fields.many2one('manage.project','Project Name'),
##        'code': fields.char('code'),
##        'new_id_name': fields.many2one('manage.customer',ondelete='cascade', select=True, readonly=True)
##        
##        }
##    _sql_constraints=[
##        ('unique_name','unique(name,new_id_name)', 'project Name must be unique')
##        ]

##    def onchange_projectname(self, cr, uid, ids, name, cust_id, context=None):
##        
##        try:
##            prod_name = self.pool.get('manage.project').browse(cr, uid, name, context=context)
##        
##            result = {
##                'name': prod_name.name
##                }
##            return {'value': result}
##        except:
##            a = 1
##    manage_projectname()

    




class address_state(models.Model):
    _name = 'address.state'
    
    name= fields.Char('State Name:',size=64,required=True,select=1)
    code= fields.Char('State Code',size=32,required=True,select=1)
    
    _sql_constraints = [
        ('code_state_uniq', 'unique (code)', 'The State code must be unique !'),
        ('name_state_uniq', 'unique (name)', 'The State Name must be unique !')
        ]
    _order = 'name'    
    
address_state()

class address_city(models.Model):
    _name = 'address.city'
    
    name= fields.Char('City Name',size=64,required=True,select=1)
    code= fields.Char('City Code',size=64,required=True,select=1)
    state_id= fields.Many2one('address.state','State',required=True)
    
    _sql_constraints = [
        ('code_state_uniq', 'unique (code,state_id)', 'The City code must be unique !'),
        ('name_state_uniq', 'unique (name,state_id)', 'The City Name must be unique !')
        ]
    _order = 'name'    
address_city()

class address_country(models.Model):
    _name = 'address.country'
    
    name= fields.Char('Country Name',size=64,required=True,select=1)
    code= fields.Char('Country Code',size=64,required=True,select=1)
     
    _sql_constraints = [
        ('code_state_uniq', 'unique (code)', 'The Country code must be unique !'),
        ('name_state_uniq', 'unique (name)', 'The Country Name must be unique !')
        ]
    _order = 'name'    
address_country()

