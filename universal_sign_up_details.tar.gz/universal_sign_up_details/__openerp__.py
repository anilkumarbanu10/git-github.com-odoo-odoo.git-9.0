# -*- coding: utf-8 -*-
#################################################################################
#
#    Copyright (c) 2015-Present Home Automat ERP. (<https://webkul.com/>)
#
#################################################################################
{
    "name": "Sign Up Screen Extend ",
    "category":'Website',
    "summary": """
        Add a mandatory field for users to share their Sign Up Screen Extend during the sign up. """,
    "description": """ """,
    "sequence": 1,
    "author": "Home Automat ERP",
    "website": "http://www.automat.co.in",
    "version": '1.0',
    "depends": ['auth_signup'],
    "data": [
        'views/res_partner_view.xml',
        'views/account_details_template.xml',
        
    ],
    "installable": True,
    "application": True,
    "auto_install": False,
    "images":['static/description/Banner.png'],
    #"price": 5,
    #"currency": 'EUR',
}