# -*- coding: utf-8 -*-
#################################################################################
#
#    Copyright (c) 2015-Present Webkul Software Pvt. Ltd. (<https://webkul.com/>)
#
#################################################################################

import logging
import werkzeug
import openerp
from openerp.addons.auth_signup.res_users import SignupError
from openerp.addons.web.controllers.main import ensure_db
from openerp import http
from openerp.http import request

_logger = logging.getLogger(__name__)
class AuthSignupHome(openerp.addons.web.controllers.main.Home):

	def do_signup(self, qcontext):
		""" Shared helper that creates a res.partner out of a token """
		values = dict((key, qcontext.get(key)) for key in ('login', 'name', 'password', 'birthday','pan_no','website','mobile'))
		assert any([k for k in values.values()]), "The form was not properly filled in."
		assert values.get('password') == qcontext.get('confirm_password'), "Passwords do not match; please retype them."
		self._signup_with_values(qcontext.get('token'), values)
		request.cr.commit()
		
		
        def _signup_with_values(self, token, values):
            type = request.params.get('type')
            if type in {"contact", "invoice"}:
                values.setdefault(type, True)
            return super(AuthSignupHome, self)._signup_with_values(token, values)

	


