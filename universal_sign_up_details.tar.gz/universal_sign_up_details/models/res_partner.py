# -*- coding: utf-8 -*-
#################################################################################
#
#    Copyright (c) 2015-Present Webkul Software Pvt. Ltd. (<https://webkul.com/>)
#
#################################################################################
from openerp import models, fields, api, _

class res_partner(models.Model):
	_inherit = 'res.partner'

	wk_dob = fields.Date('Date of Birth')
	pan_no = fields.Char('PAN Number')
        tin_no = fields.Char('TIN Number')

res_partner()